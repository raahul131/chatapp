<script>
	import Header from '../components/Header.svelte';
</script>

<main>
	<div>
		<Header />
	</div>
</main>
